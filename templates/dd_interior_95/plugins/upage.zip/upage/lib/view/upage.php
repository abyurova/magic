<!DOCTYPE html>
<html>
<head>
    <?php $startFiles = getStartFiles(); ?>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <script type="text/javascript">
        var upageSettings = <?php echo getConfigObject(); ?>;
    </script>

    <script type="text/javascript" src="<?php echo $startFiles['editor']; ?>"></script>
    <script type="text/javascript" src="<?php echo $startFiles['editor-utility']; ?>"></script>
    <script type="text/javascript" src="<?php echo $startFiles['editor-uploader']; ?>"></script>
    <script type="text/javascript" src="<?php echo $startFiles['loader']; ?>" data-processor="joomla" ></script>

    <style type="text/css">
        body {
           /* background: none transparent !important; *//* make admin panel visible */
        }

        body > [data-thumbnail] { /* hide all sections */
            display: none !important;
        }
    </style>

</head>
<body>
    <?php echo UpageSectionsManager::getSectionsContent(JRequest::getCmd('id', '')); ?>
</body>
</html>