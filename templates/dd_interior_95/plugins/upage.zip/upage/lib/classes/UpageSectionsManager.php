<?php

class UpageSectionsManager {

    public static function getSectionById($id)
    {
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('#__upage_sections');
        $query->where('id = ' . $id);
        $db->setQuery($query);
        $list = $db->loadObjectList();
        return count($list) > 0 ? $list[0] : null;
    }

    public static $upageSections = array();

    public static function sectionsParser($atts, $content = '') {

        $atts = ShortcodesUtility::atts(array(
            'id' => ''
        ), $atts);

        $id = $atts['id'];
        if (!is_numeric($id)) {
            return '';
        }

        $section = UpageSectionsManager::getSectionById($id);
        if (null == $section) {
            return '';
        }

        $root = dirname(dirname((JURI::current())));
        $screenShot = $section->image;
        $sectionAttributes = " data-thumbnail=\"$screenShot\" data-media-id=\"$id\"";

        $sectionContent = $section->content;
        $sectionContent = preg_replace('#</style>\s*<\w+#', '$0 ' . $sectionAttributes, $sectionContent);
        $sectionContent = preg_replace('#$\s*<\w+#',        '$0 ' . $sectionAttributes, $sectionContent);

        UpageSectionsManager::$upageSections[] = $sectionContent;

        return '';
    }

    public static function getSectionsContent($articleId) {
        $sections = self::getSections($articleId);
        if (count($sections) > 0) {
            return implode('', UpageSectionsManager::$upageSections);
        } else {
            return '';
        }
    }

    public static function getSections($id) {
        $content = UpagePostManager::getArticleContent($id);
        if (null !== $content) {
            require_once JPATH_PLUGINS . '/content/themlercontent/lib/Shortcodes.php';

            ShortcodesUtility::stackPush(array(
                '#^upage_section$#' => 'UpageSectionsManager::sectionsParser'
            ));

            UpageSectionsManager::$upageSections = array();

            ShortcodesUtility::doShortcode($content);

            ShortcodesUtility::stackPop();

            return UpageSectionsManager::$upageSections;
        } else {
            return array();
        }
    }

    public static $upageScreenshots = array();

    public static function screenshotParser($atts, $content = '') {
        $atts = ShortcodesUtility::atts(array(
            'id' => ''
        ), $atts);

        $id = $atts['id'];
        if (!is_numeric($id)) {
            return '';
        }

        $section = UpageSectionsManager::getSectionById($id);

        if (null == $section) {
            return '';
        }

        $screenShot = $section->image;

        if ($screenShot) {
            UpageSectionsManager::$upageScreenshots[] = sprintf('<div><a href="%s"><img src="%s"></a></div>', '', $screenShot);
        }
        return '';
    }

    public static function getScreenshots() {
        $postContent = UpagePostManager::getArticleContent(JRequest::getCmd('id', ''));
        require_once JPATH_PLUGINS . '/content/themlercontent/lib/Shortcodes.php';

        ShortcodesUtility::stackPush(array(
            '#^upage_section$#' => 'UpageSectionsManager::screenshotParser'
        ));


        UpageSectionsManager::$upageScreenshots = array();

        ShortcodesUtility::doShortcode($postContent);

        ShortcodesUtility::stackPop();
        $ret = '';
        if (count(UpageSectionsManager::$upageScreenshots) > 0) {
            $out = implode('', UpageSectionsManager::$upageScreenshots);
            $ret = <<<EOF
<style>
    #upage-preview a img {
        max-width: 100%;
    }
</style>
<div id="upage-preview">
    $out
</div>
EOF;
        }
        return json_encode($ret);
    }

    public static function buildUpageSectionsTable() {
        $db = JFactory::getDBO();
        $query = <<<EOL
CREATE TABLE IF NOT EXISTS `#__upage_sections` (
    `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
    `title` varchar(255) NOT NULL DEFAULT '',
    `content` mediumtext NOT NULL,
    `image` text NOT NULL DEFAULT '',
    PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
EOL;
        $db->setQuery($query);
        $db->query();
    }

}